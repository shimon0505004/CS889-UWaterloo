#Development setup

install NodeJS: https://nodejs.org

#Running the code

npm install

npm start

It should start a local web server at http://localhost:8000/

Any further modification of the code will trigger Webpack to recompile

Tested on NodeJS 12.16.2 and NPM 6.14.4
